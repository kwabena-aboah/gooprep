from django.contrib import admin
from .models import SiteSettings, StaticPage

@admin.register(SiteSettings)
class SiteSettingsAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):  return not SiteSettings.objects.exists()
    def has_delete_permission(self, request, obj=None): return False

@admin.register(StaticPage)
class StaticPageAdmin(admin.ModelAdmin):
    list_display = ('page_type','title','updated_at')